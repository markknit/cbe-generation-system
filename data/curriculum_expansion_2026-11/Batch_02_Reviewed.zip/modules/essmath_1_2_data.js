'use strict';
module.exports = {
  "schemaVersion": "1.1.0",
  "META": {
    "subject": "Essential Mathematics",
    "grade": 10,
    "substrand_id": "1.2",
    "substrand_name": "Indices",
    "outputDir": "v2/Essential_Mathematics/SS1.2_Indices",
    "filePrefix": "Codex_Essential_Mathematics_Indices",
    "titleDoc": "ESSENTIAL MATHEMATICS GRADE 10: INDICES",
    "subtitleDoc": "OpenAI-only evaluation • Sub-Strand 1.2 • 8 lessons • teacher review copy"
  },
  "UNIT": {
    "strand": "1.0 Numbers and Algebra",
    "substrand": "Sub-Strand 1.2: Indices",
    "sep": "Represent repeated multiplication, derive laws by factor counting/cancellation and verify models.",
    "careers": "Illustrative counting,stock organisation and data reporting; no current population or employment claims.",
    "focus": "Use four index laws with justified domains and distinguish a mathematical model from an unstated real-world pattern.",
    "phenomenon": "A stock poster multiplies exponents in one place and adds them in another,but both results look plausible.",
    "supportingPhenomena": "Factor groups,quotient cancellations,zero-power consistency and fictional packing/reporting records.",
    "drivingQuestion": "Which operation on the powers does the situation actually require? KICD: Why are indices important? How are the laws of indices applied in real life?",
    "storylineThread": "Notation → product → quotient → power of power → zero → applications → audit/source check → independent evidence.",
    "coreCompetencies": "Learning to learn: the learner shares learnt knowledge as they discuss with peers and use the laws of indices to work out mathematical computations.\nDigital literacy: the learner develops the skills of connecting and interacting with digital technology when using digital resources to search for the laws of indices.",
    "values": "Unity: the learner develops fairness and team spirit as they carry out given mathematical tasks involving the laws of indices.\nResponsibility: the learner develops leadership and guidance while discussing with peers as they work on the group tasks.",
    "pcis": "Social cohesion: the learner works with peers harmoniously to carry out given mathematical tasks involving the laws of indices.",
    "content": "Indices (powers and bases); Laws of Indices: a^m × a^n = a^(m+n); a^m ÷ a^n = a^(m−n); (a^m)^n = a^(m×n); a^0 = 1; where m and n are whole numbers; Applications of indices",
    "gradeLevel": "10",
    "subject": "Essential Mathematics",
    "totalDuration": "8 lessons × 40 minutes = 320 minutes",
    "learningOutcomes": "express numbers in index form in different situations,\ndeduce the four laws of indices from powers and bases,\napply the laws of indices in numerical computations,\nrecognise the use of indices in computations."
  },
  "LESSONS": [
    {
      "number": 1,
      "title": "What is being multiplied repeatedly?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Represent numbers as powers or products of prime powers.",
        "knowledge": "The index counts repeated factors for positive whole powers; parentheses identify the base.",
        "skills": "Expand,evaluate and factor exact numbers.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Why is 2^5 different from 2×5?",
        "purposeInStoryline": "The stock team begins a reference sheet from actual factor groups.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "The stock team begins a reference sheet from actual factor groups.\nMaterials: IX1. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict 2^5 and mark the base of(−2)^4 versus−2^4.",
          "teacherMoves": "4 minutes. Ask for factors rather than a rule recalled without explanation.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Initial representations show which negative sign is inside the base."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Complete IX1 individually,then compare factor groups.",
          "teacherMoves": "16 minutes. Allow 8 minutes expansion,4 prime-factor form and 4 comparison; use counters/boxes on paper as needed.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "32,27,16,−16;64=2^6;81=3^4;72=2^3×3^2."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain base/index and the limits of a single prime-power representation.",
          "teacherMoves": "10 minutes. Contrast repeated multiplication with base×index; show why 72 needs two prime factors.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Each learner explains a factor count without calculator dependence."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Add questions about multiplying powers to the board.",
          "teacherMoves": "4 minutes. Retain same-base versus different-base questions for Lesson 2.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "Questions identify the operation rather than just request a result."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Build the notation section with a negative-base counterexample.",
          "teacherMoves": "6 minutes. Collect an individual expansion and factorisation; diagnose integer/multiplication gaps.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:explain why 4×4×4 is 4^3,not 4×3."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Equal factors can be grouped compactly.",
        "learned": "The base is the repeated factor and the index counts copies.",
        "explained": "Parentheses and prime-factor structure preserve the exact meaning."
      }
    },
    {
      "number": 2,
      "title": "Why do exponents add in a same-base product?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Deduce and apply the product law from factor counts.",
        "knowledge": "A product joins two strings of equal factors;addition of expressions is a different operation.",
        "skills": "Derive a rule and test counterexamples.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "What must match before adding exponents?",
        "purposeInStoryline": "The poster’s first disputed calculation is a product of powers.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "The poster’s first disputed calculation is a product of powers.\nMaterials: IX2. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict 2^3×2^4 as 2^7 or 2^12 and justify with a sketch.",
          "teacherMoves": "4 minutes. Keep both claims visible;ask how many 2 s actually occur.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Learner commits to a factor-count explanation."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Solve IX2 examples and audit A–C with rotating group roles.",
          "teacherMoves": "16 minutes. Allow 8 minutes expansions,4 false-claim checks and 4 individual explanations;observe role sharing separately.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "Correct results 128,243,125;false claims corrected with actual factors."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Generalise m+n from factor strings.",
          "teacherMoves": "10 minutes. State same-base/nonzero-domain convention for this unit’s combined rules and defer the zero case’s justification.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Each learner states the operation and matching-base condition."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "List quotient and power-of-power questions separately.",
          "teacherMoves": "4 minutes. Do not merge these merely because each contains two exponents.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "A question names what happens to the powers."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add the product rule and an addition counterexample to the sheet.",
          "teacherMoves": "6 minutes. Collect one individual derived example and test of a false claim.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:explain why 2^3+2^4 is 24,not 2^7."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Joining 3 factors and 4 factors makes 7 factors.",
        "learned": "Same-base multiplication adds exponents.",
        "explained": "The rule does not combine addition or arbitrary different bases."
      }
    },
    {
      "number": 3,
      "title": "Why do exponents subtract in a quotient?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Deduce the quotient rule through cancellation with a nonzero base.",
        "knowledge": "Cancellation removes equal nonzero factors;zero denominator is excluded.",
        "skills": "Explain a quotient and its domain.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "What remains after the shared factors cancel?",
        "purposeInStoryline": "The stock team reverses a grouping operation.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "The stock team reverses a grouping operation.\nMaterials: IX3. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict 2^7÷2^3 by counting how many factors might remain.",
          "teacherMoves": "4 minutes. Require numerator/denominator factors before a compact rule.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Prediction identifies four remaining factors."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Expand and cancel the three core IX3 quotients.",
          "teacherMoves": "16 minutes. Allow 10 minutes working and 6 explanation/checking;use optional n>m example only after core understanding.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "16,25,9 with correct cancellations;no cancellation through addition."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain m−n and why a≠0 is necessary.",
          "teacherMoves": "10 minutes. Use numerator=denominator to preview the zero exponent;label 1/8 extension as a consequence,not a required fifth rule.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Each learner explains why 0/0 cannot justify a law."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Add the equal-exponent question to the board.",
          "teacherMoves": "4 minutes. Retain why a^0=1 until Lesson 5 rather than assert it by multiplying by 0.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "Learner identifies the unresolved boundary case."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add quotient rule,domain and one reverse check.",
          "teacherMoves": "6 minutes. Collect an individual cancellation argument and multiply the quotient by the divisor to check.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:justify 5^4÷5^2=25."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Equal factors cancel when their values are nonzero.",
        "learned": "Same-base division subtracts exponents in the stated domain.",
        "explained": "A quotient check connects the rule to ordinary division."
      }
    },
    {
      "number": 4,
      "title": "How many groups of factors does a power contain?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Deduce the power-of-a-power rule by repeated grouping.",
        "knowledge": "n copies of a^m contain mn copies of a.",
        "skills": "Draw groups,derive a rule and distinguish two similar expressions.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Why does this operation multiply rather than add exponents?",
        "purposeInStoryline": "A second poster calculation places brackets around a whole power.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "A second poster calculation places brackets around a whole power.\nMaterials: IX4. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict whether(2^3)^2 equals 2^3×2^2.",
          "teacherMoves": "4 minutes. Ask for a diagram of what is repeated in each expression.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Learner marks two copies of a three-factor group in the first."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Solve IX4 with expanded groups and correct the 4-base claim.",
          "teacherMoves": "16 minutes. Allow 9 minutes groups/calculations and 7 comparisons/individual explanations.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "64,729,625;product comparison 32;corrected 4^6=4096."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Generalise mn and contrast with m+n.",
          "teacherMoves": "10 minutes. Count groups and factors per group explicitly;do not treat brackets as decoration.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Individual explanation distinguishes product and power-of-power rules."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Review which operations the poster actually uses.",
          "teacherMoves": "4 minutes. Sort examples by multiplication,division and repeated powering.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "A learner chooses a rule from the written operation."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add a grouping diagram and a near-lookalike counterexample.",
          "teacherMoves": "6 minutes. Collect a derived example without a calculator-only justification.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:explain why(4^2)^3 is not 4^5."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Three groups of two factors give six factors.",
        "learned": "A power of a power multiplies exponents.",
        "explained": "The grouping operation differs from multiplying two powers."
      }
    },
    {
      "number": 5,
      "title": "What value keeps the zero-exponent pattern consistent?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Deduce the zero-exponent definition for nonzero bases.",
        "knowledge": "Equal nonzero powers have quotient 1;zero base is outside that derivation.",
        "skills": "Compare two evaluations and explain the excluded case.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Why does a^0 mean 1 rather than 0 here?",
        "purposeInStoryline": "The equal-exponent quotient question returns to the board.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "The equal-exponent quotient question returns to the board.\nMaterials: IX5. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict 7^0 and explain which prior rule could help.",
          "teacherMoves": "4 minutes. Keep initial answers visible;do not equate the exponent 0 with a factor 0.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Learner proposes the equal-power quotient or a consistent pattern."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Complete IX5 using both ordinary division and exponent subtraction.",
          "teacherMoves": "16 minutes. Allow 8 minutes derivation,4 evaluations and 4 domain/error critique.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "7^0,9^0,(−4)^0 equal 1;0^3=0;0/0 cannot support 0^0."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "State the definition with its domain and contrast positive powers of 0.",
          "teacherMoves": "10 minutes. Explicitly say this unit assigns no value to 0^0;avoid a universal claim about every mathematical convention.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Every learner includes a≠0 in the zero rule."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Close the equal-power question with evidence and retain modelling questions.",
          "teacherMoves": "4 minutes. Require both quotient evaluations when marking the question answered.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "Closure cites a valid nonzero example."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Complete the four-law reference sheet with a domain warning.",
          "teacherMoves": "6 minutes. Collect an individual explanation,not just the four formulas.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:explain why substituting 0 into the derivation fails."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Two equal nonzero quantities divide to 1.",
        "learned": "a^0=1 is defined consistently for a≠0.",
        "explained": "The definition cannot be inferred from the not defined quotient 0/0."
      }
    },
    {
      "number": 6,
      "title": "Which count model actually uses a power?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Apply index laws to supplied contexts and distinguish exact from rounded data.",
        "knowledge": "A stated grouping/pattern can justify a power;rounding and extrapolation change claims.",
        "skills": "Model counts,report rounded data and state assumptions.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Do numbers alone prove a growth rule?",
        "purposeInStoryline": "The team checks practical uses without importing unstated real-world assumptions.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "The team checks practical uses without importing unstated real-world assumptions.\nMaterials: IX6. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Predict total beads in a carton from the two group levels.",
          "teacherMoves": "4 minutes. Ask learners to name what each power counts before combining.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "The expression represents beads per box times boxes per carton."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Complete IX6 models and rounded reporting.",
          "teacherMoves": "16 minutes. Allow 10 minutes four short tasks and 6 comparison/checking;all population data are explicitly fictional.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "128,81,72,000=72×10^3;stages 9,27,81 with correct stage 0."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain why the starting 3 remains in the stage formula and why rounding is approximate.",
          "teacherMoves": "10 minutes. Compare 3×3^n with 3^n at n=0;reject a real-growth claim not supplied by the model.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Individual explanation states the model rule and lost precision."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Add questions about when a count model is warranted.",
          "teacherMoves": "4 minutes. Separate the stipulated pattern from observations that would need investigation.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "An open question targets evidence rather than assumes exponential growth."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add context → index model → ordinary check → limitation to the sheet.",
          "teacherMoves": "6 minutes. Collect one independent context explanation and rounding statement.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:explain a benefit and a limit of index notation."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Nested groups and a stipulated pattern can use compact power notation.",
        "learned": "The context determines the operation and starting multiplier.",
        "explained": "Rounded reporting loses detail;an ideal pattern is not a measured population law."
      }
    },
    {
      "number": 7,
      "title": "Can we audit and source-check our four-law sheet?",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Consolidate four derived laws and explain a counting decision.",
        "knowledge": "A reference sheet needs justified operations and domains,not only formulas.",
        "skills": "Audit a model,communicate a derivation and verify a named source.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Which evidence makes a reference rule trustworthy?",
        "purposeInStoryline": "The team prepares a checked reference for a new independent task.",
        "safetyNotes": "Use teacher-approved official page/cached copy only,no personal-data entry or unrelated links. Maintain printed access and record digital not observed where appropriate."
      },
      "overview": "The team prepares a checked reference for a new independent task.\nMaterials: IX7. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Choose among the three expressions for two stores.",
          "teacherMoves": "4 minutes. Require a sketch showing the new store rather than a larger dimension in one store.",
          "sensemakingStrategy": "Commit to an initial claim before comparing reasons.",
          "formativeAssessment": "Learner distinguishes doubling a count from adding a fourth factor 8."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Build the four-law sheet and audit the store model with individual contributions.",
          "teacherMoves": "16 minutes. Use 8 minutes sheet/model,4 peer checks and up to 4 digital verification where feasible;otherwise use the actual printed IX7 summary.",
          "sensemakingStrategy": "Record evidence before discussing explanations.",
          "formativeAssessment": "2×8^3=1024;four examples show domains and factor-based reasoning. Record digital action independent/prompted/not observed."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Defend one derivation and one reason indices are useful.",
          "teacherMoves": "10 minutes. Check that the official page’s extra properties are not silently made required. Observe respectful role rotation separately.",
          "sensemakingStrategy": "Connect a claim to evidence and identify its limits.",
          "formativeAssessment": "Each learner explains a rule and a practical computation benefit."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Audit answered/open questions and any unavailable digital evidence.",
          "teacherMoves": "4 minutes. Mark print-only digital skill not observed;plan a later accessible station before claiming it.",
          "sensemakingStrategy": "Sort questions into answered, partly answered and still open.",
          "formativeAssessment": "A remaining question or access gap is recorded honestly."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Revise the sheet and record an individual next action.",
          "teacherMoves": "6 minutes. Collect sheets/reflections for formative feedback;remove them before the independent task.",
          "sensemakingStrategy": "Preserve the first model and annotate a justified revision.",
          "formativeAssessment": "Exit:state a corrected model with a check and an explicit domain."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "Two identical stores double the original count rather than change every grouping.",
        "learned": "Law choice depends on the operation and stated conditions.",
        "explained": "A defensible reference connects formulas,derivations,checks and source limits."
      }
    },
    {
      "number": 8,
      "title": "Independent index-model audit",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 1.2: Indices",
      "aresKeywords": "Indices",
      "slo": {
        "purpose": "Demonstrate index notation,law deduction,computation and practical interpretation independently.",
        "knowledge": "The same four laws need valid operations and nonzero-base conditions in new examples.",
        "skills": "Show expanded-factor evidence,compute and explain a contextual decision.",
        "attitudes": "Record evidence honestly, listen respectfully and revise a claim when warranted.",
        "keyInquiry": "Can I justify the compact form without the group sheet?",
        "purposeInStoryline": "A new fictional stock/reporting set tests individual reasoning.",
        "safetyNotes": "Use printed tasks and calculators; keep personal information private and walkways clear."
      },
      "overview": "A new fictional stock/reporting set tests individual reasoning.\nMaterials: IX8. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 18 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 4 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Read procedure and the isolated data sheet.",
          "teacherMoves": "4 minutes. Allow 4 minutes;explain notation/calculator policy without working an example.",
          "sensemakingStrategy": "Individual work only; no comparison, hints or answer discussion before collection.",
          "formativeAssessment": "Each learner knows teaching cards are unavailable."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Complete notation and four-law reasoning independently.",
          "teacherMoves": "18 minutes. Allow 18 minutes for sections 1–2;support procedure/access only,no factor-count hints.",
          "sensemakingStrategy": "Individual work only; no comparison, hints or answer discussion before collection.",
          "formativeAssessment": "Individual expanded working and conditions are visible."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Complete contextual modelling and usefulness independently.",
          "teacherMoves": "10 minutes. Allow 10 minutes for section 3;calculators may check completed work only.",
          "sensemakingStrategy": "Individual work only; no comparison, hints or answer discussion before collection.",
          "formativeAssessment": "A conclusion distinguishes exact counts,rounded reports and unstated models."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Identify one check or condition to revisit privately.",
          "teacherMoves": "4 minutes. Allow 4 minutes,no shared question-board discussion before collection.",
          "sensemakingStrategy": "Individual work only; no comparison, hints or answer discussion before collection.",
          "formativeAssessment": "A learner records an explicit check or unresolved condition."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Check labels/working and submit all sheets.",
          "teacherMoves": "4 minutes. Allow 4 minutes and collect before any answer discussion.",
          "sensemakingStrategy": "Individual work only; no comparison, hints or answer discussion before collection.",
          "formativeAssessment": "All assessed work remains individual until collection."
        }
      ],
      "teacherReflection": "Inspect the named learner evidence before the next lesson. Record the misconception, whose work shows it, and the next support or extension; do not infer individual mastery from a group product.",
      "summaryTablePrompt": {
        "observed": "New problems reveal individual choices of notation,law and context.",
        "learned": "Teacher records demonstrated skills from collected working.",
        "explained": "Feedback addresses actual factor/domain errors rather than a group product."
      }
    }
  ],
  "FINAL_EXPLANATION": {
    "subjectLabel": "INDICES",
    "instructions": "Lesson 8:4 minutes procedure,18 minutes sections 1–2,10 minutes section 3,4 minutes private check/condition reflection and 4 minutes checking/collection,total 40. Work independently using IX8 only. Show expanded factors/cancellation where requested;state domain conditions. Calculators may check completed work but cannot replace an explanation. No required negative-exponent computation or standard-form coefficient convention beyond the stated index notation.",
    "sections": [
      {
        "title": "1. Meaning and representation",
        "prompt": "Write 3×3×3×3×3 in index and ordinary form;identify base/index. Express 144 as a product of prime powers. Evaluate(−3)^2 and−3^2 and explain the parentheses.",
        "exemplar": "3^5=243,base 3,index 5;144=2^4×3^2. (−3)^2=9;−3^2=−9 because the unbracketed leading minus is outside the squared base."
      },
      {
        "title": "2. Deduce and apply four laws",
        "prompt": "Use expanded factors or cancellation to justify 3^2×3^4,2^8÷2^5 and(5^2)^2,then give compact forms and values. For the zero law use 11^2÷11^2 to explain 11^0. State the conditions for the quotient/zero arguments and explain why they do not justify 0^0. State the general rule suggested by each calculation, including its base restriction.",
        "exemplar": "Product six 3 s:3^6=729. Quotient leaves three 2 s:2^3=8. Power has two groups of two 5 s:5^4=625.11^2/11^2=1 and 11^(2−2)=11^0,so 11^0=1. Equal bases are required for product/quotient and the quotient/zero arguments require a nonzero base.0/0 has no unique value;this unit does not assign 0^0. General rules respectively add,subtract,multiply exponents and give 1 for nonzero zero-power."
      },
      {
        "title": "3. Use and limits of the model",
        "prompt": "Use IX8:A find tiles per crate in compact and ordinary form. B report the rounded count as a whole-number multiple of 10^3 and identify lost precision. C choose a model for the total in two stores and explain why 4^4 would be inappropriate. Give one concrete benefit of indices and a check that could catch an operation error.",
        "exemplar": "A5^3×5^2=5^5=3125 tiles. B48,600 rounds to 49,000=49×10^3;the reported number omits the original detail and is approximate. C2×4^3=128 objects;adding an identical store doubles 64 rather than adding a fourth group-of 4 dimension. Indices shorten repeated-factor writing and support checked grouping arithmetic;expanding factors or comparing with the original count verifies law choice. Accept another specific supported benefit/check."
      }
    ],
    "rubric": [
      {
        "criterion": "Represent powers and distinguish their bases",
        "excellent": "All representations,values,prime factors and parentheses explanations are correct and clearly distinguish base from index.",
        "proficient": "Correctly represents/evaluates the values and explains the sign/parentheses distinction.",
        "developing": "Some correct representations but a base,index,prime factor or sign needs correction.",
        "belowExpectations": "Needs guided repeated-factor examples to interpret index notation."
      },
      {
        "criterion": "Deduce and apply the four laws",
        "excellent": "All four derivations and results are correct,with clear operation distinctions and a complete nonzero-domain explanation.",
        "proficient": "Justifies all four laws with appropriate factors/cancellation,correct values and relevant domain conditions.",
        "developing": "Applies some laws but a derivation,operation distinction or domain argument is incomplete.",
        "belowExpectations": "Needs guided support to connect a rule to the underlying factors."
      },
      {
        "criterion": "Model a count and explain the usefulness/limits of indices",
        "excellent": "All context results are correct;clearly distinguishes exact/rounded values and doubled-store structure,with a specific benefit and independent check.",
        "proficient": "Correctly models the contexts,notes lost precision and explains a relevant benefit/check.",
        "developing": "A sensible model is present but a count,rounding decision,operation explanation or usefulness reason is incomplete.",
        "belowExpectations": "Needs prompts to connect the stated grouping to an index expression and practical interpretation."
      }
    ]
  },
  "SUMMARY_TABLE": {
    "subStrand": "Sub-Strand 1.2: Indices",
    "drivingQuestion": "Which operation on the powers does the situation actually require? KICD: Why are indices important? How are the laws of indices applied in real life?",
    "lessons": [
      {
        "number": 1,
        "title": "What is being multiplied repeatedly?",
        "observed": "Equal factors can be grouped compactly.",
        "learned": "The base is the repeated factor and the index counts copies.",
        "explained": "Parentheses and prime-factor structure preserve the exact meaning."
      },
      {
        "number": 2,
        "title": "Why do exponents add in a same-base product?",
        "observed": "Joining 3 factors and 4 factors makes 7 factors.",
        "learned": "Same-base multiplication adds exponents.",
        "explained": "The rule does not combine addition or arbitrary different bases."
      },
      {
        "number": 3,
        "title": "Why do exponents subtract in a quotient?",
        "observed": "Equal factors cancel when their values are nonzero.",
        "learned": "Same-base division subtracts exponents in the stated domain.",
        "explained": "A quotient check connects the rule to ordinary division."
      },
      {
        "number": 4,
        "title": "How many groups of factors does a power contain?",
        "observed": "Three groups of two factors give six factors.",
        "learned": "A power of a power multiplies exponents.",
        "explained": "The grouping operation differs from multiplying two powers."
      },
      {
        "number": 5,
        "title": "What value keeps the zero-exponent pattern consistent?",
        "observed": "Two equal nonzero quantities divide to 1.",
        "learned": "a^0=1 is defined consistently for a≠0.",
        "explained": "The definition cannot be inferred from the not defined quotient 0/0."
      },
      {
        "number": 6,
        "title": "Which count model actually uses a power?",
        "observed": "Nested groups and a stipulated pattern can use compact power notation.",
        "learned": "The context determines the operation and starting multiplier.",
        "explained": "Rounded reporting loses detail;an ideal pattern is not a measured population law."
      },
      {
        "number": 7,
        "title": "Can we audit and source-check our four-law sheet?",
        "observed": "Two identical stores double the original count rather than change every grouping.",
        "learned": "Law choice depends on the operation and stated conditions.",
        "explained": "A defensible reference connects formulas,derivations,checks and source limits."
      },
      {
        "number": 8,
        "title": "Independent index-model audit",
        "observed": "New problems reveal individual choices of notation,law and context.",
        "learned": "Teacher records demonstrated skills from collected working.",
        "explained": "Feedback addresses actual factor/domain errors rather than a group product."
      }
    ]
  }
};
