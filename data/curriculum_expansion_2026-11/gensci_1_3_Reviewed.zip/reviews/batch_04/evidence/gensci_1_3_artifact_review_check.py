"""Read actual Word/PDF artifacts; write only this review's JSON evidence."""
from pathlib import Path
import json, hashlib, re, subprocess, sys, zipfile
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[5]
sys.path.insert(0,str(ROOT/'scripts'))
from curriculum_pipeline import content_fingerprint
W=ROOT/'data/curriculum_expansion_2026-11'
D=json.loads((W/'manuscripts/gensci_1_3.json').read_text()); M=json.loads((W/'materials/gensci_1_3.json').read_text())
OUT=next((W/'outputs/v2').rglob(D['prefix']+'_data.json')).parent
TYPES=['CBE_LessonSequence','CompactTeacherGuide','StudentMaterials','MaterialsTeacherKey','FinalExplanation','FinalExplanation_TeacherKey','SummaryTable','StudentSummaryTable','AssessmentMaterials']
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','x':'http://www.w3.org/1999/xhtml'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):
 return re.sub(r'(?<=-)\s+(?=\w)','',re.sub(r'\s+',' ',s)).strip()
hashes={}; words={}; blocks={}; streams={}; page_counts={}; trees={}
for typ in TYPES:
 docx=OUT/(D['prefix']+'_'+typ+'.docx');pdf=W/'outputs/PDF'/(D['prefix']+'_'+typ+'.pdf')
 hashes[typ]={'docx_sha256':sha(docx),'pdf_sha256':sha(pdf)}
 with zipfile.ZipFile(docx) as z:
  trees[typ]=ET.fromstring(z.read('word/document.xml'))
  words[typ]=norm(' '.join(t.text or '' for t in trees[typ].findall('.//w:t',NS)))
 xml=ET.fromstring(subprocess.check_output(['pdftotext','-bbox-layout',str(pdf),'-']))
 pages=xml.findall('.//x:page',NS);page_counts[typ]=len(pages);blocks[typ]=[]
 for page_n,page in enumerate(pages,1):
  for b in page.findall('.//x:block',NS):
   blocks[typ].append({'page':page_n,'x':float(b.attrib['xMin']),'y':float(b.attrib['yMin']),
       'text':' '.join(t.text or '' for t in b.findall('.//x:word',NS))})
 # Global block order plus per-column streams preserve split-cell continuations.
 bs=blocks[typ]; ss=[('global bbox blocks',norm(' '.join(b['text'] for b in bs))),('body excluding portrait footer',norm(' '.join(b['text'] for b in bs if b['y']<740)))]
 colspecs={'CBE_LessonSequence':[(136,278),(288,434),(440,582),(592,736)],
           'CompactTeacherGuide':[(50,145),(145,310),(310,490),(490,620),(620,760)],
           'FinalExplanation':[(60,200),(210,335),(343,470),(477,603),(610,735)],
           'FinalExplanation_TeacherKey':[(60,200),(210,335),(343,470),(477,603),(610,735),(210,735)],
           'SummaryTable':[(60,175),(180,362),(368,550),(556,735)]}
 for xmin,xmax in colspecs.get(typ,[]):
  ss.append((f'column {xmin}..{xmax}',norm(' '.join(b['text'] for b in bs if xmin<=b['x']<xmax))))
 streams[typ]=ss
rows=[]
def check(typ,label,text):
 n=norm(text); matches=[method for method,stream in streams[typ] if n in stream]
 if not matches:
  matches=[method+'; whitespace-insensitive characters' for method,stream in streams[typ] if re.sub(r'\s+','',n) in re.sub(r'\s+','',stream)]
 rows.append({'document':typ,'field':label,'word_pass':n in words[typ],'pdf_pass':bool(matches),'pdf_method':matches[0] if matches else None,**({'expected':text} if not matches else {})})
for typ in ['CBE_LessonSequence','CompactTeacherGuide']:
 for i,l in enumerate(D['lessons'],1):
  check(typ,f'lesson{i}.title',l['title'])
  for j,p in enumerate(l['phases'],1):
   for k,t in enumerate(p,1):check(typ,f'lesson{i}.phase{j}.{k}',t)
  check(typ,f'lesson{i}.reflection',l['reflection'])
  for key in (['purpose','knowledge','skills','attitudes','inquiry','story','overview','safety'] if typ=='CBE_LessonSequence' else ['purpose','knowledge','safety']):check(typ,f'lesson{i}.{key}',l[key])
for typ in ['FinalExplanation','FinalExplanation_TeacherKey']:
 check(typ,'assessment.instructions',D['assessment']['instructions'])
 for i,s in enumerate(D['assessment']['sections'],1):
  check(typ,f'assessment.section{i}.prompt',s['prompt'])
  if typ.endswith('TeacherKey'):check(typ,f'assessment.section{i}.exemplar',s['exemplar'])
 for i,r in enumerate(D['assessment']['rubric'],1):
  for k,t in r.items():check(typ,f'assessment.rubric{i}.{k}',t)
for i,l in enumerate(D['lessons'],1):
 for k,t in l['summary'].items():
  check('SummaryTable',f'lesson{i}.summary.{k}',t)
  check('CBE_LessonSequence',f'lesson{i}.summary.{k}',t)
for c in M['items']:
 check('AssessmentMaterials' if c['id']=='DG12' else 'StudentMaterials',c['id']+'.student',c['student'])
 check('MaterialsTeacherKey',c['id']+'.student',c['student']);check('MaterialsTeacherKey',c['id']+'.teacher',c['teacher'])
# Procedural isolation and blank response evidence, independent of string-presence checks.
answer_rows=[]
for table in trees['FinalExplanation'].findall('.//w:tbl',NS):
 rs=table.findall('w:tr',NS)
 if len(rs)==3:
  first=''.join(t.text or '' for t in rs[0].findall('.//w:t',NS))
  if any(first==section['title'] for section in D['assessment']['sections']):
   answer_rows.append(''.join(t.text or '' for t in rs[2].findall('.//w:t',NS)).strip())
blank_final_answers=len(answer_rows)==4 and all(t=='Write your answer here:' for t in answer_rows)
attribution={}
for typ in TYPES:
 with zipfile.ZipFile(OUT/(D['prefix']+'_'+typ+'.docx')) as z:
  xml=' '.join(z.read(p).decode() for p in z.namelist() if p.startswith('word/') and p.endswith('.xml'))
 attribution[typ]={'word':all(t in xml for t in ['ChatGPT/Codex','OpenAI']),
                   'pdf':all(any(t in stream for _,stream in streams[typ]) for t in ['ChatGPT/Codex','OpenAI'])}

blank=True
for r in trees['StudentSummaryTable'].findall('.//w:tbl/w:tr',NS)[1:]:
 for c in r.findall('w:tc',NS)[1:]:
  blank=blank and not ''.join(t.text or '' for t in c.findall('.//w:t',NS)).strip()
student_exemplars_absent={typ:all(norm(s['exemplar']) not in words[typ] and not any(norm(s['exemplar']) in t for _,t in streams[typ]) for s in D['assessment']['sections']) for typ in ['FinalExplanation','StudentMaterials','AssessmentMaterials']}
export=json.loads((OUT/(D['prefix']+'_data.json')).read_text()); finalslots={phase:{k:v[k] for k in ('video','reading')} for phase,v in export['LESSONS'][-1]['resourceLinks'].items()}
selected=[{'lesson':l['number'],'phase':phase,'kind':k,'title':v[k]['title'],'source':v[k]['source']} for l in export['LESSONS'] for phase,v in l['resourceLinks'].items() for k in ('video','reading') if v[k]]
allowed=json.loads((W/'resource_policy.json').read_text()).get('module_allowed_titles',{}).get('gensci_1_3',[])
initial=json.loads((W/'reviews/batch_04/evidence/gensci_1_3_review_binding.json').read_text())
bridge={}
for typ in initial['draft_word_hashes']:
 oldtext=(W/'reviews/batch_04/evidence'/f'gensci_1_3_{typ}_review_text.txt').read_text()
 bridge[typ]={'initial_docx_sha256':initial['draft_word_hashes'][typ],'current_docx_sha256':hashes[typ]['docx_sha256'],'binary_same':initial['draft_word_hashes'][typ]==hashes[typ]['docx_sha256'],'body_text_matches_initial_extract':norm(oldtext)==norm('\n'.join(''.join(t.text or '' for t in p.findall('.//w:t',NS)) for p in trees[typ].findall('.//w:p',NS))),'bridge_method':'Same paragraph-joined w:t extraction as initial evidence;whitespace collapse only'}
audit=json.loads((W/'evidence/batch_04_gensci_1_3_artifact_audit.json').read_text())
auditmatch=all(hashes[r['type']]['docx_sha256']==r['docx_sha256'] and hashes[r['type']]['pdf_sha256']==r['pdf_sha256'] for r in audit['documents'])
acceptance=json.loads((W/'reviews/gensci_1_3/content_acceptance.json').read_text())
initial_review_match=all(sha(ROOT/r['path'])==r['sha256'] for r in acceptance['evidence'])
result={'frozen_audit_hashes_match':auditmatch,'initial_review_evidence_current':initial_review_match,'companion_rebuild_bridge':bridge,'content_fingerprint':content_fingerprint(W,'gensci_1_3'),'artifact_hashes':hashes,'pdf_pages':page_counts,'checks':rows,'checks_total':len(rows),
        'word_pass':sum(r['word_pass'] for r in rows),'pdf_pass':sum(r['pdf_pass'] for r in rows),
        'blank_final_answer_cells':blank_final_answers,'attribution_openai':attribution,'blank_student_summary':blank,'student_exemplars_absent':student_exemplars_absent,
        'final_DG12_absent_teaching_student':all('DG12' not in stream for _,stream in streams['StudentMaterials']) and 'DG12' not in words['StudentMaterials'],
        'final_slots':finalslots,'final_slots_null':all(x is None for v in finalslots.values() for x in v.values()),'selected_resources':selected,'selected_titles_allowed':all(r['title'] in allowed for r in selected),
        'normalization':'First collapse whitespace and join whitespace after retained hyphens. Fallback ignores whitespace only (PDF adds spaces at wrapped algebra/long comma lists); all nonspace characters, punctuation and mathematical glyphs retained. Column streams recover same-cell page continuations.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks_total':len(rows),'word_pass':result['word_pass'],'pdf_pass':result['pdf_pass'],'failures':[r for r in rows if not r['word_pass'] or not r['pdf_pass']]},ensure_ascii=False,indent=2))

if not auditmatch or not initial_review_match:
 raise SystemExit('Frozen audit or accepted evidence hash mismatch')
if not all(v['body_text_matches_initial_extract'] for v in bridge.values()):
 raise SystemExit('Companion body-text bridge failed')
if result['word_pass']!=len(rows) or result['pdf_pass']!=len(rows) or not all([blank,blank_final_answers,result['final_DG12_absent_teaching_student'],result['final_slots_null'],result['selected_titles_allowed'],*student_exemplars_absent.values()]) or not all(all(v.values()) for v in attribution.values()):
 raise SystemExit(1)
