'use strict';
module.exports = {
  "schemaVersion": "1.1.0",
  "META": {
    "subject": "Core Mathematics",
    "grade": 10,
    "substrand_id": "2.5",
    "substrand_name": "Area of Polygons",
    "outputDir": "v2/Core_Mathematics/SS2.5_Area_of_Polygons",
    "filePrefix": "Codex_Core_Mathematics_Area_of_Polygons",
    "titleDoc": "CORE MATHEMATICS GRADE 10: AREA OF POLYGONS",
    "subtitleDoc": "OpenAI-only evaluation • Sub-Strand 2.5 • 12 lessons • teacher review copy"
  },
  "UNIT": {
    "strand": "2.0 Measurements and Geometry",
    "substrand": "Sub-Strand 2.5: Area of Polygons",
    "content": "Area of a triangle using A=1/2 ab sin C; area of a triangle using Heron’s formula; area of quadrilaterals; area of regular and irregular polygons; application of area of polygons.",
    "coreCompetencies": "Critical Thinking and Problem Solving: the learner uses trigonometric ratios to generate the formula for a triangle given two sides and an included angle.\nCreativity and Imagination: the learner identifies from the immediate environment objects in the shape of regular polygons and calculates their area.\nLearning to Learn: the learners research and discuss the use of the area of polygons in real-life situations.",
    "values": "Patriotism: the learner uses the objects from the environment and takes care of the environment.\nResponsibility: the learner identifies objects from the immediate environment to use in calculating the area of regular polygons.\nPeace: the learner harmoniously discusses in groups and uses trigonometric ratios to generate the formula for the area of a triangle given two sides and an included angle.",
    "pcis": "Environmental Education: the learner collects objects from the immediate environment to be used as learning materials for area of polygons.",
    "sep": "Geometric construction, derivation, measurement and independent calculation.",
    "careers": "Surveying, construction, landscaping and estimating.",
    "focus": "Choose and justify an area method from verified dimensions; distinguish geometric calculation from field measurement.",
    "phenomenon": "A fictional school garden has triangular and irregular beds. A tempting side-times-side estimate overstates how much covering is needed.",
    "supportingPhenomena": "Labelled model diagrams, scale drawings and regular-polygon designs; no measurements are claimed to be from a real school.",
    "drivingQuestion": "How can we defend a garden covering estimate? KICD: How do we work out the area of polygons? How do we apply the concept of the area of polygons in real-life situations?",
    "storylineThread": "Height misconception -> sine derivation -> Heron -> scale -> quadrilaterals -> diagonals -> regular polygons -> heptagon/octagon -> irregular regions -> coordinate plan -> application -> assessment.",
    "gradeLevel": "10",
    "subject": "Core Mathematics",
    "totalDuration": "12 lessons × 40 minutes = 480 minutes",
    "learningOutcomes": "derive the formula for the area of a triangle given two sides and an included angle,\nwork out the area of a triangle given two sides and an included angle,\ndetermine the area of a triangle using Heron’s formula,\ndetermine the area of quadrilaterals in different situations,\nwork out the area of regular heptagon and octagon,\ndetermine the area of irregular polygons in different situations,\nexplore the area of polygons as used in real-life situations."
  },
  "LESSONS": [
    {
      "number": 1,
      "title": "A sloping side is not a height",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "Triangle area uses a perpendicular height.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Sketch and solve C1; compare 20 m² with the proposed 40 m².",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Sketch and solve C1; compare 20 m² with the proposed 40 m².\nMaterials: C1. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C1 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Sketch and solve C1; compare 20 m² with the proposed 40 m².",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Height 4 m and area 20 m²; explanation identifies the right angle."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Identify the perpendicular from C to AB and explain why AC is not that height.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Height 4 m and area 20 m²; explanation identifies the right angle."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Begin a garden-area model: known sides and included angle determine the perpendicular height.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Height 4 m and area 20 m²; explanation identifies the right angle.",
        "learned": "Triangle area uses a perpendicular height.",
        "explained": "AC is sloping; the perpendicular height is 8 sin 30°=4 m, so the triangle area is 20 m², not 40 m²."
      }
    },
    {
      "number": 2,
      "title": "Derive and use the sine area rule",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "A=ab sinθ/2 when θ is included between a and b.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Draw the C2 construction and derive the formula before calculating the practice area.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Draw the C2 construction and derive the formula before calculating the practice area.\nMaterials: C2. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C2 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Draw the C2 construction and derive the formula before calculating the practice area.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Derivation is visible; practice area≈36.37 cm²."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain the substitution h=a sinθ and why the included angle matters.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Derivation is visible; practice area≈36.37 cm²."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add the sine-area rule, its included-angle condition and square units.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Derivation is visible; practice area≈36.37 cm².",
        "learned": "A=ab sinθ/2 when θ is included between a and b.",
        "explained": "Since sinθ=h/a, h=a sinθ and A=bh/2=ab sinθ/2 for the stated included angle; the practice area is 21√3 cm², about 36.37 cm²."
      }
    },
    {
      "number": 3,
      "title": "Heron’s formula and valid triangles",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "Heron’s formula uses three side lengths and a semiperimeter.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Check the triangle inequalities and solve both C3 cases, rejecting the impossible triangle.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Check the triangle inequalities and solve both C3 cases, rejecting the impossible triangle.\nMaterials: C3. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C3 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Check the triangle inequalities and solve both C3 cases, rejecting the impossible triangle.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "s 21 m and 84 m²; 3, 4, 8 rejected before attempting a square root."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Compare needing three sides with needing two sides and their included angle.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "s 21 m and 84 m²; 3, 4, 8 rejected before attempting a square root."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add a three-side branch to the method-selection model.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "s 21 m and 84 m²; 3, 4, 8 rejected before attempting a square root.",
        "learned": "Heron’s formula uses three side lengths and a semiperimeter.",
        "explained": "The 13, 14, 15 m triangle has semiperimeter 21 m and area 84 m²; 3, 4, 8 m cannot form a triangle because 3+4<8."
      }
    },
    {
      "number": 4,
      "title": "Scale and measurement precision",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "An area scale factor is the square of the linear factor.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Draw C4 to scale and compute the full plot area; compare with the drawn triangle.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Draw C4 to scale and compute the full plot area; compare with the drawn triangle.\nMaterials: C4. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C4 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Draw C4 to scale and compute the full plot area; compare with the drawn triangle.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Drawn 13, 14, 15 cm; plot area 2100 m²; measurement caveat stated."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain the dimensionless scale 1: 500: 1 cm² represents 250000 cm²=25 m², so the 84 cm² drawing represents 2100 m². Keep the drawing and field units explicit.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Drawn 13, 14, 15 cm; plot area 2100 m²; measurement caveat stated."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Distinguish an exact model calculation from a measured field estimate.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Drawn 13, 14, 15 cm; plot area 2100 m²; measurement caveat stated.",
        "learned": "An area scale factor is the square of the linear factor.",
        "explained": "The scale is 1: 500; 1 cm² represents 25 m², so the 84 cm² drawing corresponds to 2100 m². Rounded field lengths limit the precision of the real estimate."
      }
    },
    {
      "number": 5,
      "title": "Parallelograms and trapezia",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "Perpendicular height connects quadrilateral and triangle area rules.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Draw and solve both C5 shapes using decompositions, then compare formula methods.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Draw and solve both C5 shapes using decompositions, then compare formula methods.\nMaterials: C5. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C5 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Draw and solve both C5 shapes using decompositions, then compare formula methods.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "60 m² and 44 m², with perpendicular heights labelled."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain how a pair of congruent trapezia gives a parallelogram.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "60 m² and 44 m², with perpendicular heights labelled."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add the parallel-side and perpendicular-height conditions.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "60 m² and 44 m², with perpendicular heights labelled.",
        "learned": "Perpendicular height connects quadrilateral and triangle area rules.",
        "explained": "A parallelogram uses base times perpendicular height (60 m²); the trapezium uses half the parallel-side sum times perpendicular height (44 m²)."
      }
    },
    {
      "number": 6,
      "title": "Diagonals with and without right angles",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "The half-product diagonal rule requires perpendicular diagonals.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Solve C6(a),(b), then split the general quadrilateral in(c).",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Solve C6(a),(b), then split the general quadrilateral in(c).\nMaterials: C6. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C6 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Solve C6(a),(b), then split the general quadrilateral in(c).",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "40 cm², 42 cm² and 35 m²; two component areas shown for(c)."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain why a diagonal-length product alone is insufficient for an arbitrary quadrilateral.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "40 cm², 42 cm² and 35 m²; two component areas shown for(c)."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add separate rules for perpendicular diagonals and a general triangle decomposition.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "40 cm², 42 cm² and 35 m²; two component areas shown for(c).",
        "learned": "The half-product diagonal rule requires perpendicular diagonals.",
        "explained": "Perpendicular diagonals give 40 cm² for the rhombus and 42 cm² for the kite; the general quadrilateral instead sums two triangles to 35 m²."
      }
    },
    {
      "number": 7,
      "title": "Regular polygons as congruent triangles",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "A regular polygon has area nsr/2 using its apothem.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Draw a regular-polygon centre fan and derive the C7 rule; solve the hexagon example.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear. Teacher supplies clean reused paper/card and rulers; no unknown waste, outdoor trip or sharp cutting tools. Record model-only fallbacks honestly."
      },
      "overview": "Draw a regular-polygon centre fan and derive the C7 rule; solve the hexagon example.\nMaterials: C7; C13. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C7 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Use C13 to identify and measure a prepared square from clean reused material, then derive the C7 rule and solve its hexagon example.",
          "teacherMoves": "16 minutes. Use 4 minutes for C13 identification/measurement, 8 minutes for individual C7 derivation/calculation and 4 minutes for comparison. Prepare safe clean material and rulers before class; no outdoor collection or sharp cutting tools.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "n congruent triangles and area≈41.57 cm²; apothem correctly drawn."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Identify the apothem as a perpendicular height rather than a radius to a vertex.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "n congruent triangles and area≈41.57 cm²; apothem correctly drawn."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add a regular-polygon branch with side count, side length and apothem.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "n congruent triangles and area≈41.57 cm²; apothem correctly drawn.",
        "learned": "A regular polygon has area nsr/2 using its apothem.",
        "explained": "A regular polygon consists of n congruent centre triangles, giving A=nsr/2 with the apothem r as perpendicular height; the hexagon area is 24√3 cm²."
      }
    },
    {
      "number": 8,
      "title": "Calculate the heptagon and octagon",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "A half-centre triangle gives r=(s/2)/tan(180°/n).",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Construct the right-triangle relation in C8 and calculate both polygon areas.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Construct the right-triangle relation in C8 and calculate both polygon areas.\nMaterials: C8. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C8 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Construct the right-triangle relation in C8 and calculate both polygon areas.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Heptagon 58.1 m² and octagon 77.3 m²; degree mode and apothem method clear."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain 180°/n versus 360°/n; retain intermediate digits until final rounding.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Heptagon 58.1 m² and octagon 77.3 m²; degree mode and apothem method clear."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add a check that the calculated apothem belongs to the stated regular polygon.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Heptagon 58.1 m² and octagon 77.3 m²; degree mode and apothem method clear.",
        "learned": "A half-centre triangle gives r=(s/2)/tan(180°/n).",
        "explained": "The half-centre angle is 180°/n; r=(s/2)/tan(180°/n), giving heptagon 58.1 m² and octagon 77.3 m² to 1 decimal place."
      }
    },
    {
      "number": 9,
      "title": "Decompose an irregular region",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "Add nonoverlapping areas or subtract a missing region.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Draw the C9 L-shape and find its area in two ways.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Draw the C9 L-shape and find its area in two ways.\nMaterials: C9. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C9 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Draw the C9 L-shape and find its area in two ways.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Both methods give 68 m²; no overlap or missing strip."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain why the two decompositions cover exactly the same region.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Both methods give 68 m²; no overlap or missing strip."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add an irregular-region branch and a check for gaps and double counting.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Both methods give 68 m²; no overlap or missing strip.",
        "learned": "Add nonoverlapping areas or subtract a missing region.",
        "explained": "Subtracting 4×3 from 10×8 and adding 10×5 to 6×3 both cover the same region exactly once and give 68 m²."
      }
    },
    {
      "number": 10,
      "title": "Read an irregular polygon from coordinates",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "A coordinate plan can support decomposition without a new formula.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we work out the area of polygons?",
        "purposeInStoryline": "Plot C10 on squared paper and verify its area with two decompositions.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Plot C10 on squared paper and verify its area with two decompositions.\nMaterials: C10. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C10 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Plot C10 on squared paper and verify its area with two decompositions.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Six ordered vertices correctly drawn; 39 m² by both methods."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain how coordinates fix lengths and how the 1 m unit becomes square metres.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Six ordered vertices correctly drawn; 39 m² by both methods."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Add a plan-reading check before choosing any area formula.",
          "teacherMoves": "6 minutes. Keep the earlier diagram; annotate the new method and its conditions in a second colour.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect one labelled diagram and a sentence defending the method."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Six ordered vertices correctly drawn; 39 m² by both methods.",
        "learned": "A coordinate plan can support decomposition without a new formula.",
        "explained": "The coordinates define an 8×6 bounding rectangle with a 3×3 corner missing: area 39 m², also 8×3+5×3."
      }
    },
    {
      "number": 11,
      "title": "Defend a real-life estimate",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Select and justify an area method using a labelled model.",
        "knowledge": "An area estimate supports a purchasing decision under explicit assumptions.",
        "skills": "Draw labelled diagrams, calculate with units and check the result.",
        "attitudes": "Listen to alternative reasoning, record evidence honestly, and revise a claim when evidence warrants it.",
        "keyInquiry": "How do we apply the concept of the area of polygons in real-life situations?",
        "purposeInStoryline": "Solve C11 and write a short recommendation to the fictional garden club.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "Solve C11 and write a short recommendation to the fictional garden club.\nMaterials: C1; C9; C11; C13. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 16 min, Explain 10 min, Driving Question Board (DQB) Creation 4 min, Model Building 6 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Inspect C1 and predict a method or possible error before calculating.",
          "teacherMoves": "4 minutes. Allow silent thinking, then ask partners to compare what is known and unknown. Ask “Which dimension or condition would change your method?” Allow 10–15 seconds of thinking, then cold-call two learners without evaluating the first answer immediately.",
          "sensemakingStrategy": "Individual prediction, then paired comparison: keep the initial claim visible.",
          "formativeAssessment": "Check that the prediction refers to dimensions rather than the visual size of the sketch."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Solve C11 and write a short recommendation to the fictional garden club.",
          "teacherMoves": "16 minutes. Use the Student Materials card. Work individually for 8 minutes, compare methods for 4 and prepare a labelled explanation for 4. Offer a pre-drawn outline or read dimensions aloud if needed.",
          "sensemakingStrategy": "Evidence-first group work: record working or observations before comparing explanations.",
          "formativeAssessment": "Correct areas and cost; no invented waste allowance or overlap."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Explain the 88 m² total, 13200 KES cost and at least two limits of the model.",
          "teacherMoves": "10 minutes. Ask two learners to show working, then have the class identify the essential assumption. Check a different learner rather than taking a chorus response.",
          "sensemakingStrategy": "Claim–evidence–reasoning: connect the result to a rule and state its limits.",
          "formativeAssessment": "Correct areas and cost; no invented waste allowance or overlap."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Update the class question board using today’s evidence.",
          "teacherMoves": "4 minutes. Ask which earlier claim can now be answered and which still depends on an unmeasured dimension.",
          "sensemakingStrategy": "Question sorting: mark an inquiry answered only when evidence supports it.",
          "formativeAssessment": "Require an evidence reference, not just an “answered” sticker."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "Complete the C13 evidence note for one actual local use of area, or explicitly record a supplied-model fallback; discuss the result and its limit.",
          "teacherMoves": "6 minutes. Use the existing 6 minutes for a brief observation/source note and discussion instead of copying the full method guide. Record object/source, dimension, area, use and limit; require no spending or off-site visit.",
          "sensemakingStrategy": "Revise a shared model: preserve the earlier version and annotate what changed.",
          "formativeAssessment": "Collect each learner’s attributed use-of-area note; distinguish actual observation from fictional or supplied-model evidence."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Correct areas and cost; no invented waste allowance or overlap.",
        "learned": "An area estimate supports a purchasing decision under explicit assumptions.",
        "explained": "Separate nonoverlapping beds total 20+68=88 m²; at KES 150/m² the model cost is 13200 KES. Cutting waste, pack sizes or measurement uncertainty may change a real order."
      }
    },
    {
      "number": 12,
      "title": "Independent polygon-area assessment",
      "duration": "40 minutes",
      "substrand": "Sub-Strand 2.5: Area of Polygons",
      "aresKeywords": "Area of Polygons",
      "slo": {
        "purpose": "Demonstrate area reasoning independently with the stated method cues.",
        "knowledge": "Select area rules from the information available and state their conditions.",
        "skills": "Draw, calculate, explain and check units.",
        "attitudes": "Work independently, record reasoning honestly, and check the stated assumptions.",
        "keyInquiry": "Can I justify the method used and its assumptions?",
        "purposeInStoryline": "An individual assessment applies taught methods to changed dimensions. Some prompts name or cue the method; it does not establish unprompted selection of every formula.",
        "safetyNotes": "Use paper tasks and calculators; keep walkways clear."
      },
      "overview": "An individual assessment applies taught methods to changed dimensions. Some prompts name or cue the method; it does not establish unprompted selection of every formula.\nMaterials: C12. Use the companion Student Materials and Teacher Materials Key. Pacing: Predict 4 min, Observe 30 min, Explain 2 min, Driving Question Board (DQB) Creation 1 min, Model Building 3 min.",
      "framework": [
        {
          "phase": "Predict Phase",
          "learnerExperience": "Read C12 and identify the required shapes.",
          "teacherMoves": "4 minutes. Give only the C12 student card and C12 diagram sheet, plus the student Final Explanation; withhold C1–C11 and all teacher keys. Allow 4 minutes to clarify wording, not select formulae.",
          "sensemakingStrategy": "Read and interpret the task individually; clarify wording without discussing methods or answers.",
          "formativeAssessment": "Check every learner can read the dimensions."
        },
        {
          "phase": "Observe Phase",
          "learnerExperience": "Complete the five assessment sections independently.",
          "teacherMoves": "30 minutes. Allow 30 minutes. Basic scientific calculator in degree mode is permitted. Do not open optional ARES resources or search links until original assessment work is collected. Provide a printed outline as an access adjustment without giving perpendicular heights.",
          "sensemakingStrategy": "Independent written working: no peer comparison, group solution or teacher exemplars before original work is collected.",
          "formativeAssessment": "Collect work before discussing solutions."
        },
        {
          "phase": "Explain Phase",
          "learnerExperience": "Write a private reflection about one method choice.",
          "teacherMoves": "2 minutes. Use 2 minutes; keep the collected answers unchanged.",
          "sensemakingStrategy": "Private reflection after collection; keep original responses unchanged and defer worked feedback.",
          "formativeAssessment": "Record an identified checking method."
        },
        {
          "phase": "Driving Question Board (DQB) Creation",
          "learnerExperience": "Submit one remaining area question.",
          "teacherMoves": "1 minutes. Use 1 minute to collect questions for feedback.",
          "sensemakingStrategy": "Submit an individual question for later feedback without discussing assessment solutions.",
          "formativeAssessment": "Use questions to plan reteaching."
        },
        {
          "phase": "Model Building Phase",
          "learnerExperience": "State one condition a real garden measurement would need to satisfy.",
          "teacherMoves": "3 minutes. Use 3 minutes for individual written transfer.",
          "sensemakingStrategy": "Write an individual transfer statement using the assessed model; no shared revision during assessment.",
          "formativeAssessment": "Assess whether the learner distinguishes model assumptions from field evidence."
        }
      ],
      "teacherReflection": "Which learner work shows the intended outcome? Record one unresolved misconception and the adjustment needed before the next lesson.",
      "summaryTablePrompt": {
        "observed": "Independent diagrams and working show method selection.",
        "learned": "Each rule depends on specific geometric information.",
        "explained": "The independent results are 12 m², 12 m², 24 m², about 14.5 m², about 19.3 m² and 57 m², each justified by its dimensions and formula conditions."
      }
    }
  ],
  "FINAL_EXPLANATION": {
    "subjectLabel": "AREA OF POLYGONS",
    "instructions": "Time: 30 minutes within Lesson 12. Use C12 and show labelled sketches, formula choice, working and units. Scientific calculator allowed, in degree mode. Round the two regular-polygon areas to 1 decimal place. Other answers may be exact. Do not assume a sketch is drawn to scale.",
    "sections": [
      {
        "title": "1. Derive and apply",
        "prompt": "For triangle A, show with a perpendicular height why A=ab sinθ/2 for the given acute included angle. Calculate its area.",
        "exemplar": "Height=6 sin 30°=3 m if 8 m is the base. A=1/2×8×3=12 m². In general h=a sinθ, so A=bh/2=ab sinθ/2."
      },
      {
        "title": "2. Three side lengths",
        "prompt": "Use Heron’s formula to find the area of triangle B; show the semiperimeter and substitution, and state why its side lengths form a valid triangle.",
        "exemplar": "5+5>6 and the other inequalities hold. s=8 m; A=√(8×3×3×2)=12 m²."
      },
      {
        "title": "3. A quadrilateral",
        "prompt": "Find the area of trapezium C. Explain the role of its stated height.",
        "exemplar": "A=(6+10)×3/2=24 m². Height is perpendicular distance between the parallel sides, not a sloping side."
      },
      {
        "title": "4. Regular polygons",
        "prompt": "For each polygon D, explain the congruent-triangle method and calculate area using the supplied apothem.",
        "exemplar": "A=nsr/2. Heptagon 7×2×2.076521/2≈14.5 m². Octagon 8×2×2.414214/2≈19.3 m². Each centre triangle has base s and perpendicular height r."
      },
      {
        "title": "5. An irregular region and a practical limit",
        "prompt": "Find the area of E by subtraction and by a nonoverlapping decomposition. Explain one reason a real covering order could differ from this calculated area.",
        "exemplar": "9×7−3×2=57 m². A decomposition is 9×5+6×2=57 m². Real cutting waste, pack sizes or measurement uncertainty may change an order; accept another justified limitation."
      }
    ],
    "rubric": [
      {
        "criterion": "Derive and apply the sine-area rule",
        "excellent": "Gives a correct, complete explanation and independently checks the result or its limits.",
        "proficient": "Meets the stated criterion with correct reasoning and an appropriate conclusion.",
        "developing": "Shows relevant understanding but needs support to correct a significant error or omission.",
        "belowExpectations": "Does not yet demonstrate the criterion; needs guided work with a concrete example."
      },
      {
        "criterion": "Apply Heron’s formula and quadrilateral methods",
        "excellent": "Gives a correct, complete explanation and independently checks the result or its limits.",
        "proficient": "Meets the stated criterion with correct reasoning and an appropriate conclusion.",
        "developing": "Shows relevant understanding but needs support to correct a significant error or omission.",
        "belowExpectations": "Does not yet demonstrate the criterion; needs guided work with a concrete example."
      },
      {
        "criterion": "Calculate regular heptagon and octagon areas",
        "excellent": "Gives a correct, complete explanation and independently checks the result or its limits.",
        "proficient": "Meets the stated criterion with correct reasoning and an appropriate conclusion.",
        "developing": "Shows relevant understanding but needs support to correct a significant error or omission.",
        "belowExpectations": "Does not yet demonstrate the criterion; needs guided work with a concrete example."
      },
      {
        "criterion": "Decompose irregular regions and justify a practical estimate",
        "excellent": "Gives a correct, complete explanation and independently checks the result or its limits.",
        "proficient": "Meets the stated criterion with correct reasoning and an appropriate conclusion.",
        "developing": "Shows relevant understanding but needs support to correct a significant error or omission.",
        "belowExpectations": "Does not yet demonstrate the criterion; needs guided work with a concrete example."
      }
    ]
  },
  "SUMMARY_TABLE": {
    "subStrand": "Sub-Strand 2.5: Area of Polygons",
    "drivingQuestion": "How can we defend a garden covering estimate? KICD: How do we work out the area of polygons? How do we apply the concept of the area of polygons in real-life situations?",
    "lessons": [
      {
        "number": 1,
        "title": "A sloping side is not a height",
        "observed": "Height 4 m and area 20 m²; explanation identifies the right angle.",
        "learned": "Triangle area uses a perpendicular height.",
        "explained": "AC is sloping; the perpendicular height is 8 sin 30°=4 m, so the triangle area is 20 m², not 40 m²."
      },
      {
        "number": 2,
        "title": "Derive and use the sine area rule",
        "observed": "Derivation is visible; practice area≈36.37 cm².",
        "learned": "A=ab sinθ/2 when θ is included between a and b.",
        "explained": "Since sinθ=h/a, h=a sinθ and A=bh/2=ab sinθ/2 for the stated included angle; the practice area is 21√3 cm², about 36.37 cm²."
      },
      {
        "number": 3,
        "title": "Heron’s formula and valid triangles",
        "observed": "s 21 m and 84 m²; 3, 4, 8 rejected before attempting a square root.",
        "learned": "Heron’s formula uses three side lengths and a semiperimeter.",
        "explained": "The 13, 14, 15 m triangle has semiperimeter 21 m and area 84 m²; 3, 4, 8 m cannot form a triangle because 3+4<8."
      },
      {
        "number": 4,
        "title": "Scale and measurement precision",
        "observed": "Drawn 13, 14, 15 cm; plot area 2100 m²; measurement caveat stated.",
        "learned": "An area scale factor is the square of the linear factor.",
        "explained": "The scale is 1: 500; 1 cm² represents 25 m², so the 84 cm² drawing corresponds to 2100 m². Rounded field lengths limit the precision of the real estimate."
      },
      {
        "number": 5,
        "title": "Parallelograms and trapezia",
        "observed": "60 m² and 44 m², with perpendicular heights labelled.",
        "learned": "Perpendicular height connects quadrilateral and triangle area rules.",
        "explained": "A parallelogram uses base times perpendicular height (60 m²); the trapezium uses half the parallel-side sum times perpendicular height (44 m²)."
      },
      {
        "number": 6,
        "title": "Diagonals with and without right angles",
        "observed": "40 cm², 42 cm² and 35 m²; two component areas shown for(c).",
        "learned": "The half-product diagonal rule requires perpendicular diagonals.",
        "explained": "Perpendicular diagonals give 40 cm² for the rhombus and 42 cm² for the kite; the general quadrilateral instead sums two triangles to 35 m²."
      },
      {
        "number": 7,
        "title": "Regular polygons as congruent triangles",
        "observed": "n congruent triangles and area≈41.57 cm²; apothem correctly drawn.",
        "learned": "A regular polygon has area nsr/2 using its apothem.",
        "explained": "A regular polygon consists of n congruent centre triangles, giving A=nsr/2 with the apothem r as perpendicular height; the hexagon area is 24√3 cm²."
      },
      {
        "number": 8,
        "title": "Calculate the heptagon and octagon",
        "observed": "Heptagon 58.1 m² and octagon 77.3 m²; degree mode and apothem method clear.",
        "learned": "A half-centre triangle gives r=(s/2)/tan(180°/n).",
        "explained": "The half-centre angle is 180°/n; r=(s/2)/tan(180°/n), giving heptagon 58.1 m² and octagon 77.3 m² to 1 decimal place."
      },
      {
        "number": 9,
        "title": "Decompose an irregular region",
        "observed": "Both methods give 68 m²; no overlap or missing strip.",
        "learned": "Add nonoverlapping areas or subtract a missing region.",
        "explained": "Subtracting 4×3 from 10×8 and adding 10×5 to 6×3 both cover the same region exactly once and give 68 m²."
      },
      {
        "number": 10,
        "title": "Read an irregular polygon from coordinates",
        "observed": "Six ordered vertices correctly drawn; 39 m² by both methods.",
        "learned": "A coordinate plan can support decomposition without a new formula.",
        "explained": "The coordinates define an 8×6 bounding rectangle with a 3×3 corner missing: area 39 m², also 8×3+5×3."
      },
      {
        "number": 11,
        "title": "Defend a real-life estimate",
        "observed": "Correct areas and cost; no invented waste allowance or overlap.",
        "learned": "An area estimate supports a purchasing decision under explicit assumptions.",
        "explained": "Separate nonoverlapping beds total 20+68=88 m²; at KES 150/m² the model cost is 13200 KES. Cutting waste, pack sizes or measurement uncertainty may change a real order."
      },
      {
        "number": 12,
        "title": "Independent polygon-area assessment",
        "observed": "Independent diagrams and working show method selection.",
        "learned": "Each rule depends on specific geometric information.",
        "explained": "The independent results are 12 m², 12 m², 24 m², about 14.5 m², about 19.3 m² and 57 m², each justified by its dimensions and formula conditions."
      }
    ]
  }
};
